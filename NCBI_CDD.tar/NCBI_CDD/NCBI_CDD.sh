#!/bin/bash


#1. download protein file from NCBI (CDD_NCBI new folder where protein file will be stored)
python3 NCBICDD_Download.py


#2. generate Homo_sapiens_CDD.Json
# . add manually curated protein domain
# . Will cause error and exit running process if protein_manuallyCurated.json missed from current directory
# . ISO screening and generate Homo_sapiens_CDD.Json. Only keep the preferred isoform listed in ISOLIST
    # . ISOLIST file "your prefered isoform accession ID file with one id each row"   
    # . if not ISOLIST file in current directory, the script will ask if you want all isoform, you need to input "y" through keyboard, otherwise the process will be aborted with error info
python3 CDD_extraction.py -p CDD_NCBI -s Homo_sapiens 

#3. sqlite db 
#sqlite3 proteindomain.db <proteindomain.sql 


rm -rf CDD_NCBI 
